package main
import (
"fmt"
"time"

)
func main() {
rand.Seed(time.Nom().UnixNano()
ch:=make(chan interface{})
func(){
rand.Intn(n:100)
}()
}
