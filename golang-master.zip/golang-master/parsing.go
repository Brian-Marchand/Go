package main

import "fmt"

type User struct {

type SignUp struct {
 UserName     string   `json:"Login" bson:"Paul"`
 Password    string   `json:"password" bson:"123"`
}
type SignUps []SignU

